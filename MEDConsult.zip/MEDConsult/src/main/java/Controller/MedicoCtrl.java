/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;
import Model.Medico;

/**
 *
 * @author mathe
 */
public class MedicoCtrl {
    String crm;
    
    public MedicoCtrl(){
        // abrir nova conexão com BD
    }
    public void adiciona(Medico medico){
        System.out.println("Medico adicionado com sucesso!");
    }
}
